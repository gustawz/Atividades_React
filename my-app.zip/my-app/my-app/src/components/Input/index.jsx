export default function Input() {
    return <input className="input" type="text" />
}